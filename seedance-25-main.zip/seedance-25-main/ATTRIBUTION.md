# Attribution and sources

This skill is original work. Nothing in it is copied text. Where it builds on someone else's thinking,
that is credited here.

## Craft lineage

The directing discipline in `references/craft-essentials.md` (prompt spine, camera and light vocabulary,
audio budget, anti-slop, IP gate, retake triage) follows the approach established by the **`seedance-20`
skill by Iamemily2050 (@iamemily2050), MIT licensed**. That skill is the deeper reference for Seedance
2.0 work, multilingual prompting, and API details, and is worth installing alongside this one if you work
with Seedance regularly.

This skill is written to stand alone and does not require it.

## Field reports

Everything labeled `[community 2026-08-04]` traces to one of two X Articles published that day:

- **PJ Ace (@PJaccetturo), "One-Take Filmmaking with Seedance 2.5: Viral Cheat Codes"**
  `https://x.com/PJaccetturo/status/2084508865400320018`
  Source for the staged one-take formula, Video Extension, Ultra-Long, Smart Edit, the pro tools, the
  verbatim repair lines, the audio tag syntax, the language tiers, and the reference sweet spots. Cites
  practitioners @knightama, @techhalla, @jerrod_lew, @shiri_shh and @XCaliber.

- **Machina (@EXM7777), "How to master Seedance 2.5 (Full Course)"**
  `https://x.com/EXM7777/status/2084666171446726767`
  Source for building reference images ahead of time in a separate image model, group-range tags, and
  corroboration of the reference sweet spots.
  **This piece was sponsored by Higgsfield**, disclosed in its closing line. Its claims about Higgsfield
  are treated as vendor marketing and recorded as a watch item in `references/surface-profiles.md`, not
  as a change in availability.

Both are practitioner reports, not documentation. That is why the evidence grading in `SKILL.md` exists
and why `[community]` claims are marked as unusable in client material without your own verification.

**How those reports held up.** When official documentation appeared on 2026-08-07, the reference sweet
spots both practitioners published turned out to be **correct**, and the "ByteDance internal guidance"
one of them cited turned out to be real. Two claims did not survive: Ultra-Long at 30-180s and the 60s
Extension ceiling appear in neither the documentation nor the model card. Both are still recorded, and
both are now marked as contradicted. A tag called `@ClayRender1`, used in v1.x of this skill, was never
real and has been removed.

## Official documentation

Since 2026-08-09 the model-level facts in this skill come from BytePlus ModelArk's own documentation,
all read on that date:

- **"Dreamina Seedance 2.5 prompt guide"**, `https://docs.byteplus.com/en/docs/ModelArk/2607689`
  (document last updated 2026-08-07). Source for the locked/unlocked task split, `content.role`, the
  trigger words, timestamp rules, the task catalogue, reference budgets, the prompt macro-structure,
  and the camera and action guidance in `references/official-spec.md`.
- **Model list**, `https://docs.byteplus.com/en/docs/ModelArk/1330310`. Source for the model ID
  `dreamina-seedance-2-5-260628`, the 480p/720p ceiling, 4-30s duration, 24 fps, mp4/mov, and the rate
  limits.
- **Pricing**, `https://docs.byteplus.com/en/docs/ModelArk/1544106`.

ByteDance also publishes its **own** prompt-optimisation skill for 2.5, `sd25-pe`, installable with
`npx skills` from `https://arkdocs-en.tos-ap-southeast-1.volces.com/skills/`. This skill is not
affiliated with it and does not bundle it. See `references/official-spec.md` section 12.

Earlier launch-window facts came from ByteDance and CapCut product pages, TechNode, and CineD from
2026-07-31 onward, plus live checks against the Magnific and Higgsfield model catalogs on 2026-08-03
and again on 2026-08-07. Those two checks disagreed: on the 3rd neither surface carried 2.5, on the 7th
both did.

**All of it has a shelf life.** Re-verify before quoting any number to a client.

## License

MIT. Use it, change it, pass it on.
