# Modes and workflows

last_verified: 2026-08-09

Sources for sections 1-5 and 7: **PJ Ace, "One-Take Filmmaking with Seedance 2.5: Viral Cheat Codes",
X Article, 2026-08-04**, plus practitioners cited inside it (@knightama, @techhalla, @jerrod_lew,
@shiri_shh, @XCaliber).
Source for section 6: **Machina (@EXM7777), "How to master Seedance 2.5 (Full Course)", 2026-08-04**,
**a piece sponsored by Higgsfield**, disclosed in its closing line.

**The baseline evidence grade of this file is `[community 2026-08-04]`.** First-hand reports from
people shipping with the model, not documentation. Usable as method. Not usable as a factual claim in
a client deck or a paid post until verified in a live UI.

> **Revised 2026-08-09.** Official documentation was published (see `official-spec.md`) and it does
> not support two numbers in this file:
>
> - **Ultra-Long at 30-180s** does not appear in the documentation at all, and the model's documented
>   duration is **4-30s**. It has not been deleted here, because a UI feature can exist outside the
>   API. But **an official source contradicts it**, and that is how it should be described.
> - **The 60s ceiling on Extension** is a community figure. Officially, extension duration is
>   user-defined and no ceiling is stated.
>
> The documentation **did confirm** editing, extension, first/last frame, the reference sweet spots,
> and that coarse blockouts outperform fine ones. It also added rules that were missing here entirely:
> mandatory trigger words, `ratio = adaptive`, `duration = -1`, and the mov format. **Those live in
> `official-spec.md` and take precedence over anything in this file.**

---

## Mode picker: four modes

In the video generation panel `[community 2026-08-04]`:

| Mode | For | Hard constraint |
|---|---|---|
| **Omni Reference** | default. Text plus any mix of image/video/audio references | reference ceiling is surface-specific |
| **Smart Edit** | upload a video, describe the change | source aspect ratio and duration **cannot be changed** `[official]` |
| **Ultra-Long Video** | one generation, 30-180s (clock icon, slider) | **not documented officially**; the documented duration is 4-30s |
| **First & Last Frame** | lock the opening and closing image, model builds the path | locks the aspect ratio `[official]` |

Before writing a mode into a settings block, confirm **what it is called on that surface** in
`surface-profiles.md`. This picker is described from CapCut. Other surfaces may use different words.

**This picker is not the whole catalogue.** The documentation also describes keyframe references,
storyboard references, 3D clay-model references, one-click video creation, and seamless transitions.
The full list with limits is in `official-spec.md` section 7.

---

## 1. The 30-second one-take

Not one long paragraph. A **script in stages**.

```
[0-8s] A florist stands behind a workbench trimming stems.
End state: she holds the finished bouquet in her left hand.

[8-16s] She wraps the bouquet in kraft paper and ties a green ribbon.
End state: the wrapped bouquet lies centered on the workbench.

[16-24s] She places it on the pickup shelf and smiles at the camera.
End state: bouquet centered on the shelf.

Keep her identity, clothing, and the workbench layout consistent throughout.
No subtitles, no background music.
```

Three rules hold it up:

1. **One primary change per stage.** Two changes in one window means the model drops one or rushes both.
2. **An explicit `End state:` on every stage.** The beat says what happens, the end state says where it
   lands, which gives the next stage something to attach to. Without it, stages blur together.
3. **A consistency line at the end.** Not instead of the constants at the top, in addition to them. The
   constants establish the world, the closing line reminds the model of it thirty seconds later.

**Time windows are budgets, not frame-exact cuts.** Give a beat too little time and the model does not
trim it, it rushes it. Three ten-second stages beat five six-second ones.

**Relationship to the four-beat skeleton in `SKILL.md`:** beats handle dramaturgy (exposition,
development, escalation, callback), staged end states handle machine continuity. Use both at once. They
do not compete.

---

## 2. Extension, the nesting-doll technique

Generate a clip (≤30s), hit Video Extension, choose **4-30 seconds**, and write a prompt **for the new
part only**. The original frames stay untouched. The **60-second ceiling** on the final cut is
`[community 2026-08-04]`; the documentation states none. Do not quote it to a client as a number.

Why you want it: you re-roll only the part that failed, not the whole clip. At 30 seconds that is the
difference between one retry and four.

**What the official documentation adds** `[official 2026-08-07]`, and without it this will not behave:

- **The prompt must contain a trigger word:** `extend forward`, `extend backward`, `continue`,
  `continue from`, or `extend the story`. Without one, the model cannot tell this is an extension.
- **The aspect ratio locks** to the source video. `ratio = adaptive`, and the user does not pick it.
  **Duration is user-defined.**
- **With several input videos, the model picks which one to extend based on the prompt.** Name the one
  you mean.
- **Use mov on the input and the output.** This is about colour and audio continuity. Loudness can
  drift slightly between the source and the new stretch, and that drift is smallest when the source
  was itself generated by 2.5.
- Extension runs **both directions**. `extend backward` generates what came before.

Official example shape: *"Extend @Video 1 by 5 seconds. A bee flies in and lands on the flower…"*

**Boilerplate for every extension prompt:**

```
Extend the video naturally, smooth motion continuity, no hard cuts,
nothing appears out of thin air.
```

**Two patterns that turn this into a technique:**

- **The controlled reveal.** Generate the calm scene first and confirm it is right. Only then extend it
  with the twist ("a UFO streaks past the window; the coffee cup shatters"). You re-roll the twist and
  never the setup. On client work this is where the money is saved.
- **The action relay.** Hard moves land more reliably chopped into extensions: generate "draws the
  sword", extend "lunges forward", extend "turns and sheathes". One movement per pass.

---

## 3. Smart Edit, changing finished footage

**Formula: target + change + timing + what stays the same.**

```
Edit @Video1. From seconds 1-8, replace the man's jeans with black tailored trousers.
Keep his identity, motion, the camera movement, and everything else in the scene unchanged.
```

With **Advanced Edit** (upload a local video and a toolbar appears with boxes, arrows, and markers you
draw directly on a frame), you can pin the change to a region:

```
Replace the sheep inside the red box with a brown horse, matching the original motion path,
only during seconds 7-15.
```

Audio edits separately:

```
Remove only the background music. Keep the dialogue, lip sync, ambience,
and all visuals exactly as they are.
```

**Hard constraints**, all now confirmed by documentation `[official 2026-08-07]`:

- Editing **preserves the source aspect ratio and duration**. You cannot change them, so do not ask.
  On the API that is `ratio = adaptive` and `duration = -1`.
- Keep the edit source **≤20 seconds**. Longer is unreliable.
- Already-generated clips are edited through a Video Edit button, local files through upload.
- **The prompt must contain a trigger word:** `edit video`, `add`, `insert`, `remove`, `delete`,
  `modify`, `replace`, or `change to`.
- **Output duration can differ by up to about 0.3 seconds.** The model compresses some transition
  frames; the content stays complete. With a source generated by 2.5, the difference is zero.
- **`output_format = mov`.**
- With several input videos, name the one you mean.

**Three capabilities this file did not previously mention:**

- **Editing with reference images.** Not just text: images can steer the result too. *"Replace the man
  in dark clothing in the video with @Image 2."* Sweet spot **1-5 images**, stretch 6-8.
- **Audio editing as its own discipline.** Add, change, or remove voice, music, and effects. It also
  does **dialogue translation with lip re-sync**: *"Translate the spoken dialogue in the video into
  Spanish, with no subtitles. Precisely adjust the lip movements to match the translated speech, while
  keeping everything else unchanged."* For anyone localising an ad across markets, that is the single
  most useful sentence in the documentation.
- **Timestamps inside an edit.** *"Change the man's action from drinking coffee to mopping the floor
  from 4-6 seconds in Video 1, and leave the rest of the content unchanged."*

**A formula the documentation confirms:** describe the change **from A to B**, not just the target
state. "Make the coat red" is weaker than "change his black coat to red".

**What Smart Edit is not:** it is not a replacement for editing. Timeline work, captions, a music bed
under the whole film, and export formats belong in a video editor. Smart Edit changes what is *inside*
the shot.

---

## 4. Ultra-Long video (30-180s), not officially documented

> **Read this before using it.** `[community 2026-08-04]` The only source is a practitioner report
> from 2026-08-04. The official documentation published 2026-08-07 **does not mention Ultra-Long**,
> and the model card gives a duration of **4-30s**. Either it is a UI feature that stitches several
> generations underneath, or the practitioner described it imprecisely. **When someone asks whether
> 2.5 can do three minutes, the answer is "it is not in the documentation, check the slider in your
> UI", not "yes".** This must not appear in a sponsored or ambassador post in any form.

If the mode does exist in your UI, everything from the 30-second recipe applies, scaled up, plus three
things, because long generations drift:

1. **Restate the global parameters at the top** ("Full video 3 minutes, 16:9…").
2. **Write the consistency requirements at the start AND at the end** of the prompt. Not once. Twice.
3. **Re-mention your references throughout,** not only in the first paragraph.

Proven structure: one beat per time window, each carrying camera, action, dialogue, and sound, closed by
a single global paragraph of style plus forbidden items.

**Before offering this to anyone:** 180 seconds is the most expensive button in the app. Test the look on
a short clip, then commit the length. Draft-first is not optional here.

---

## 5. Pro tools

Most of this section became **documented tasks** on 2026-08-07 rather than tricks. Labels are per item.

- **Green screen, both directions.** `[community 2026-08-04]` "The white background becomes a green
  screen" for clean plates, or composite a green-screen clip into a scene with automatic lighting and
  perspective matching. This is the only item here with no official backing.
- **Blockouts, officially 3D clay-model reference** `[official 2026-08-07]`. Export a camera move or
  animatic from Maya or Blender and map the primitives to references. **Coarse blockouts work better
  than fine ones**, confirmed by the documentation. The official mapping shape: *"Map the man in gray
  clothing from [Image 1] to the red model in [Video 1], and replace the green model 2 in [Video 1]
  with the red-haired girl from [Video 2]."* **State exactly what is taken from the clay video**
  (camera, motion, and lighting changes if any), or the model takes things you did not intend. Full
  rules in `official-spec.md` section 10.
- **Storyboard grids** `[official 2026-08-07]`. Line art or stick figures, **≤15 panels**, clean lines,
  and **no text on the board**. The important clarification from the documentation: **a storyboard does
  not bind the output.** Panels are a rough plot, not a raster. When the output must match exactly,
  the tool is keyframes, not a storyboard.
- **Keyframe reference** `[official 2026-08-07]`, **new here**. Each image goes in as a separate
  reference in order, and the prompt opens with the literal line *"Use Images 1 to 7 in order as
  keyframes."* The output follows them **strictly**. This is the tool for "the client wants exactly
  this board".
- **Joining two clips** `[official 2026-08-07]`, documented as **seamless video transition**.
  `"Seamlessly connect [Video 1] and [Video 2]"` plus a description of the bridge and a line saying the
  input videos must not be altered. The model generates only the connective tissue.
- **One-click video creation** `[official 2026-08-07]`, **new here**. Builds a short video from a pile
  of images and clips, and will choose an order if you let it: *"Turn all images into a one-click
  video… The images may move slightly, creating a live-photo effect, but do not alter the original
  images."*

---

## 6. Reference images are built beforehand, outside Seedance

**Those 30 image slots do not come from Seedance.** They are made by hand in an image model before you
write the first line of the video prompt. Skip this and you end up chasing character consistency with
video re-rolls, which is the most expensive possible way to do it.

Four steps:

1. **Lock one look for the whole project.** In Midjourney that is an `--sref` code, either from the style
   creator after 20-22 picks or by rolling `--sref random` until two or three codes look right. In any
   other tool it means picking one model and one style description and holding it. One look for all
   references, not a look per image.
2. **Generate by category, not at random.** Typically: wide establishing shot, environment, main
   character, key prop, closing shot. Each gets its own short prompt.
3. **Anything that appears more than once gets a reference sheet:** front, side, back, blank background.
   This is what later lets the same character or object drop into a new scene without being redrawn.
4. **Once the references are locked, do not touch them.** If the motion looks wrong, fix the motion
   prompt. **Never regenerate the image.** A new image throws away all the consistency you just built.
   This is the most important rule in this section.

**Tool choice by what the shot needs** `[community]`: stylized, illustrated, anime, anything with a
distinct art direction goes to Midjourney. Realism, real faces, real materials and light goes to
GPT Images 2 or Nanobanana Pro. The IP gate in `craft-essentials.md` applies to reference images exactly
as it applies to video.

**Where to keep them:** one page per asset plus one index page, in whatever knowledge tool the team
already uses. The point is that 30 images, 10 clips, and 10 audio files is more than anyone remembers,
so it has to be something you look up rather than recall. Review it after each session or it turns into
a folder of dead files.

**Realistic budget:** a full reference set for one project is an afternoon of work, staying inside the
1-8 range that actually holds rather than the 50-slot number that looks impressive on a spec sheet.

---

## 7. Cost discipline

- **Generate at 480p while you are still iterating.** `[community 2026-08-04, @XCaliber]` Pull several
  shots out of one 30-second generation, upscale separately, and cut in a normal editor. Cheaper than
  generating high-resolution takes and throwing them away.
- **Iterate on short segments through Extension,** not at full length.
- **Stay inside the recommended reference ranges.** Exceeding them is a more common cause of re-rolls
  than a bad prompt.
- A 180-second run costs serious credits. It is not something you click to see what happens.
