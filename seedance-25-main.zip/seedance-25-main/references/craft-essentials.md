# Craft essentials

The directing vocabulary this skill assumes. Written to be self-contained, so nothing here depends on
another skill being installed.

The rule underneath all of it: **describe what a camera could record.** A model cannot render an
adjective. It renders a lens, a movement, a light source, and a physical consequence.

---

## 1. The prompt spine

Every shot, at any length, states six things:

| Slot | What goes in it | Failure if omitted |
|---|---|---|
| **Subject** | who or what, described physically | the model invents a look and changes it mid-clip |
| **Action** | a verb and its consequence | drifting camera and invented business fill the time |
| **Camera** | framing, lens, movement, height | a slow aimless push-in by default |
| **Light and setting** | source, direction, quality, place | flat even light that reads synthetic |
| **Style** | grade, texture, era, medium | defaults to glossy stock-video look |
| **Sound** | ambience, effects, dialogue, music or its absence | generic library music appears uninvited |

At 30 seconds you write all six **per beat**, not once for the clip. That is the actual work the
longer duration creates. The list did not change, the number of times you use it did.

This spine sits inside the four-block macro-structure ByteDance's documentation prescribes: asset
referencing, then a one-sentence summary, then the detailed plot, then the notes on what stays
consistent. See `official-spec.md` section 4.

---

## 2. Camera

Name the frame, the movement, and the height. Three short specifics beat one long adjective.

- **Framing:** wide establishing, medium, medium close-up, close-up, extreme close-up, over-the-shoulder,
  two-shot, insert.
- **Movement:** static, slow push-in, pull-back dolly, tracking alongside, orbit, crane up, tilt,
  whip pan, handheld drift, arm's-length selfie framing.
- **Height and angle:** eye level, low angle, high angle, overhead.
- **Lens feel:** wide with visible distortion, long lens with compressed background, shallow depth of
  field with a specific plane in focus.

Two rules that save takes:

- **One movement per shot.** An orbit and a pull-back in the same beat produce a mush of both. If you
  need two moves, that is two beats.
- **Describe the shake instead of the rig.** "Handheld micro-jitter, natural body sway as she walks"
  works. "Shot on a gimbal" does not, because the model renders images, not equipment.

---

## 3. Light

Name the **source**, its **direction**, and its **colour temperature** separately. A single flat light
is the fastest way to make a scene look synthetic.

- Warm key against a cool ambient fill is what reads as real.
- Hard directional light gives crisp speculars and sharp shadow edges up close. Let atmospheric haze
  soften things at distance. That sharp-to-soft shift with distance does a lot of the realism work.
- Let shadows pick up bounced colour from what is nearby, cool from open sky, warm from stone or wood,
  rather than one uniform fill tone.
- Put weight on edges: a rim light catching stray hair, a flare that blooms exactly when the camera
  tilts toward the sun, highlights that roll off smoothly instead of clipping to flat white.
- Let distant layers lose contrast and saturation. Skipping atmospheric perspective is the fastest way
  to make a real-looking scene look rendered.

For product work, invert most of this: large diffused sources, minimal shadow, a thin rim tracing
translucent edges, an infinite backdrop with no competing environment.

---

## 4. Sound and dialogue

Audio and video are generated together in one pass, so timing is locked by construction. You are not
adding a track afterward, you are asking one model to commit to both at once.

- **The audio budget is per line and per breath, not per clip.** Thirty seconds is room for more lines,
  not permission for longer ones. One thought per breath.
- Lip sync holds up best on medium close-ups with simple, clear phoneme shapes. Write the delivery into
  the prompt: crisp diction, open vowels, staccato phrasing. Whispered or mumbled delivery falls apart.
- For non-English dialogue, name the language and the accent before the line.
- Silence is a choice you have to make explicitly. If you do not specify sound, library-grade music
  tends to appear. See the `[SOUND]` kill switch in `proven-fixes.md`.
- Tag syntax for audio elements is in `proven-fixes.md`.

---

## 5. Anti-slop

These words carry no information and actively degrade output, because the model has seen them attached
to every kind of image and so they steer nothing:

> cinematic, stunning, breathtaking, ethereal, majestic, glow, magical, epic, hyper-realistic,
> masterpiece, award-winning, 8K, ultra-detailed, dramatic lighting, perfect composition

Replace each with the thing it was gesturing at:

| Slop | What to write instead |
|---|---|
| cinematic | the actual lens, movement, and grade |
| dramatic lighting | the source, its direction, its colour |
| stunning / breathtaking | nothing. Delete it. It has no referent |
| ethereal glow | "haze catching a low sun behind her, highlights blooming softly" |
| hyper-realistic | skin texture, fabric weave, a real light source |
| epic | scale described by a foreground element against a distant one |

Rule of thumb: if removing the word changes nothing about what a camera would record, remove it.

---

## 6. IP, likeness, and brand gate

Run this before writing the first sentence. It is not optional and being a platform ambassador or
partner is not authorization to use anyone else's property.

**Stop and resolve before prompting if the brief involves:**

- A **real person's face or voice**, including public figures and celebrities. Generating a recognizable
  real person without their documented consent is the single highest-risk thing you can do with this
  model. Most surfaces block it, and the ones that do not still leave you liable.
- A **protected character, franchise, or exact scene** from an existing film, game, or series.
- A **third-party brand, logo, or product identity** you are not authorized to depict.
- **Songs or recognizable score.**

**Safe rewrites:**

| Risk | Rewrite |
|---|---|
| named celebrity | an original archetype described physically, no name |
| protected character | original design with the same function in the story |
| brand logo on screen | the client's own mark, or no mark at all |
| known song | described mood and tempo, or licensed audio supplied as a reference |
| real person the client supplies | proceed only with written consent on file, and say so |

Outputs typically carry a visible watermark plus provenance metadata, and invisible watermarking is
assumed to be present. Treat any output as traceable.

---

## 7. Retake triage

When a generation comes back wrong, change **one thing** and re-run. Changing four things teaches you
nothing about which one mattered.

| What went wrong | What to change |
|---|---|
| Clip fell apart into unrelated shots | one subject, one intent, beats as phases of one arc |
| Character changed halfway | constants block at the top, restated at the bottom |
| A reference leaked its look into the shot | add the exclusion line to that tag |
| The ending just stops | callback in beat four to an object or frame from beat one |
| Cut lands mid-movement | end the beat's sentence on the impact |
| Motion looks weightless | write the verb and its consequence, not a pose |
| Stages blur into each other | add `End state:` to every stage |
| A beat feels rushed | widen the window or remove a change. Windows are budgets |
| Wrong look, right motion | fix the reference image, not the prompt |
| Wrong motion, right look | fix the prompt, and **do not** regenerate the reference image |

That last pair is the one people get backwards most often. Once your reference images are locked, a new
image throws away all the consistency work they were doing.
