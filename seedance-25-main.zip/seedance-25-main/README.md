# seedance-25 skill

A Claude skill that writes production-ready **Seedance 2.5** prompts for any surface that runs the model:
Dreamina web, CapCut Desktop, Jimeng, Doubao, and eventually the API.

Built for people who make video for a living and want the model to behave like a crew instead of a slot
machine.

## What it does

- **30-second prompts** staged with explicit end states and integer-second timestamps, so the shot does
  not drift
- **The locked/unlocked task split**, which decides whether you get to choose the aspect ratio and
  duration at all, plus the API parameters and trigger words each task requires
- **Editing finished footage**: swap subjects, change actions on a timestamp, translate dialogue with
  lip re-sync, strip or replace audio
- **Video Extension** forward or backward, with the continuity rules that keep the seam invisible
- **Keyframes, storyboards, and 3D clay-model references**, including which one to reach for when the
  output has to match a board exactly
- **Reference binding** with a role and an exclusion per asset, which is the single biggest quality lever
- **Surface profiles** so you never quote a limit that does not apply to the tool you are actually in
- **Verbatim repair lines** for the failures everyone hits: music that will not go away, faces that drift,
  crowds that look like clones

## Install

**On claude.ai:** Settings → Capabilities → Skills → Upload skill, and drop `seedance-25.zip` in as it
is. Do not unzip it first and do not re-zip it yourself. The uploader requires `SKILL.md` to sit in the
archive's top-level folder, and re-zipping from a Mac usually adds a wrapper folder that breaks exactly
that. Upload runs a short security scan before the skill goes live.

**In Claude Code:** unzip and copy the whole `seedance-25` folder, including its `references/`
subfolder, into a skills directory:

```
# project-level, available in one repo
cp -R seedance-25 /path/to/your/project/.claude/skills/

# or user-level, available everywhere
cp -R seedance-25 ~/.claude/skills/
```

Restart the session. Check it loaded with `/seedance-25`, or just describe a video and it should trigger
on its own.

**The one thing that breaks it:** copying the loose `.md` files instead of the folder. `SKILL.md` looks
for its reference files in `references/`. Keep the structure intact.

It works in Claude Code, Claude Desktop, and anything else that reads the standard skill format.

## What it is not

- **It does not generate anything.** The output is always a copy-paste prompt plus the settings block.
  Where you run it is your call.
- **It is not an editor.** Timeline work, captions, music beds, and export belong in your NLE.
- **It is not for Seedance 2.0.** 2.0 is a separate line at 4-15 seconds with 9 images / 3 videos /
  3 audio. Mixing the two up is the most common mistake made about this model.

## The resolution thing, before you plan a shoot around it

**Seedance 2.5 runs at 480p and 720p. It does not do 1080p and it does not do 4K.** Not through the
API, not in CapCut, not in Dreamina, not through an agent. That is the model, not a surface limitation
(`dreamina-seedance-2-5-260628`, per the BytePlus model list, read 2026-08-09).

If you need a 1080p or 4K master, that is **Seedance 2.0 at 15 seconds**. 2.5 buys you length, a much
larger reference budget, timestamps, and editing of finished footage, and it charges you resolution for
all of it.

Versions 1.x of this skill got this wrong and told people to go to CapCut for higher resolution. There
is nothing there. That correction is the reason for the v2.0.0 bump.

## Read this before quoting numbers to a client

Seedance 2.5 launched **2026-07-31** and got official documentation on **2026-08-07**. A lot of what
exists about it online is still launch reporting or vendor marketing. Every factual claim in this skill
carries an evidence label: `[official]`, `[press]`, `[community]`, `[verified-live]`, or `[unverified]`.

Anything marked `[community]` is a working method, not a fact you can put in a pitch deck. Anything
unlabeled should not be stated as a number at all. The skill enforces this by writing `(verify in UI)`
into the settings block wherever a value has not been confirmed for your surface.

Two figures circulating widely are **not** in the official documentation: **Ultra-Long at 30-180
seconds** and a **60-second ceiling for Video Extension**. The documented duration is 4-30 seconds.
Both claims are kept in the skill, clearly marked as contradicted by the model card, because a UI
feature can exist outside the API. Do not repeat either as fact.

Catalogs and features change weekly. Re-check before promising. Worked example: on 2026-08-03 neither
Magnific nor Higgsfield carried 2.5 in their model catalogs. On 2026-08-07 both did. Four days. Every
number in here has a date on it for exactly that reason.

## Changelog

- **v2.0.0** (2026-08-09): rebuilt against BytePlus ModelArk's official documentation. **Breaking
  correction:** 2.5 is 480p/720p only, never 1080p or 4K. Adds `references/official-spec.md` with the
  locked/unlocked task split, `content.role`, mandatory trigger words for editing and extension,
  integer-second timestamp rules, the full task catalogue (keyframes, storyboards, 3D clay models,
  one-click video, seamless transitions), and official reference budgets. Publishes the model ID
  `dreamina-seedance-2-5-260628`, rate limits, and pricing. Retires three invented claims: the
  `@ClayRender1` tag, the "no spaces in tags" rule, and the seven-beat ceiling. Downgrades Ultra-Long
  and the 60s Extension ceiling to contradicted community claims.
- **v1.1.0** (2026-08-07): Magnific and Higgsfield now run 2.5 through an agent at 4-30s, 720p/480p
  only. Surface profiles, the dividing line in `SKILL.md`, and the output contract updated against live
  catalog reads.
- **v1.0.0** (2026-08-06): first release.

## Contents

```
seedance-25/
├── SKILL.md                          the core: surface gate, beats, reference binding, checklist
├── ATTRIBUTION.md                    sources, credit, license
└── references/
    ├── official-spec.md              locked/unlocked tasks, API params, trigger words, task catalogue
    ├── craft-essentials.md           prompt spine, camera, light, sound, anti-slop, IP gate, retakes
    ├── surface-profiles.md           per-surface capabilities and settings blocks
    ├── beat-templates.md             four ready skeletons with worked examples
    ├── modes-and-workflows.md        Extension, Smart Edit, keyframes, storyboards, reference prep
    └── proven-fixes.md               verbatim repair lines, audio syntax, languages, reference limits
```

Self-contained. No other skill required.

## License

MIT. See `ATTRIBUTION.md` for sources and credit.
