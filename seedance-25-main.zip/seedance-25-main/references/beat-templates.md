# Beat templates for 30-second Seedance 2.5

Skeletons, not text to copy verbatim. Each holds the four-beat structure from `SKILL.md`, one arc, and a
callback in beat four. Prompts are in English because that is how they go into the UI.

**Surface-neutral.** Mode names in parentheses are generic (text to video, image to video, reference).
What the mode is called on a given surface, and what its reference ceiling is, comes from
`surface-profiles.md` before you use a template.

Run everything past the anti-slop list in `craft-essentials.md`. Adjectives like "cinematic", "stunning",
"breathtaking", and "ethereal glow" are deliberately absent from these templates and must not creep in.

**The `End state:` convention:** every beat closes with a line stating what the window should end on. The
beat describes the action, the end state gives the model an anchor for the join. All four templates use
it. Use it in anything you build yourself. It is the cheapest edit with the largest effect on 30-second
coherence.

**The closing consistency line** is the other half of the same idea: constants at the top establish the
world, the closing line reminds the model of it thirty seconds later. Both, not one or the other.

**Two things from the official documentation that change how you use these** `[official 2026-08-07]`:

1. **The time windows here are a 2.5-only feature.** Seedance 2.0 ignores timestamps and understands
   only shot numbers. If you recycle a template onto 2.0, **rewrite `00-06s` as `Shot 1`** or the model
   invents the timing. On 2.5, use whole seconds and **make sure the timeline has no gaps**.
2. **Four windows is not a ceiling.** ByteDance's own 30-second examples run 8 and 9 shots at 2-4
   seconds each. These templates use four because four is memorable and holds a clean arc, not because
   more is unsupported. When a clip has denser action, go to eight windows and take something out of
   each one.

---

## 1. Product spot (text to video or image to video)

**When:** a client product, one hero, the goal is desire and a clean close.

```
Constants for the whole clip: matte black ceramic kettle on a pale oak counter, morning kitchen,
single window as the only light source, cool desaturated grade, shallow depth of field, no on-screen text.

00-06s: Wide establishing shot of the empty counter, window light crossing the surface, steam not yet
present. Camera static. Room tone, a distant street.
End state: the counter is still empty, the light unbroken.

06-14s: A hand enters frame and sets the kettle down. Slow push-in to a three-quarter medium. The switch
clicks. Water begins to move inside.
End state: the kettle sits centered on the counter, the switch down, the hand gone from frame.

14-24s: Tracking move around the kettle as steam builds and catches the window light. The metal surface
fogs from the base upward. The boil rises under the room tone.
End state: the kettle is fully fogged and steam fills the window light.

24-30s: Cut to a close-up of the switch releasing, steam thinning, the same window light now across the
empty counter behind it. The room settles back to silence.
End state: the switch is up, the steam gone, the counter behind it empty as in the opening.

Keep the kettle, the counter, and the window light direction unchanged throughout.
No on-screen text, no background music.
```

**Callback:** beat four returns to the empty counter from beat one. The viewer closes the loop without
being told to.

---

## 2. Explainer clip (text to video)

**When:** a training clip or an educational post. Legibility beats effect.

```
Constants: one presenter in a grey crew-neck, plain concrete studio wall, key light from camera left,
warm practical lamp behind on the right, natural grade, no text overlays, no logos.

00-06s: Medium shot of the presenter facing camera, hands resting. Static frame. He says, "Most people
prompt the wrong thing first."
End state: he holds the camera's eye, hands still resting.

06-14s: Slow push to a tighter medium as he turns a quarter to his left toward the empty wall. "They
describe the look. The model needs the action."
End state: he is in a tighter medium, angled a quarter left, the wall empty behind him.

14-24s: Handheld drift to the right, the practical lamp flaring softly at the edge of frame. He lifts one
hand to mark a beat. "Say what changes. Then say what holds."
End state: his raised hand is at chest height, the lamp flare at the right edge of frame.

24-30s: Settle back to the opening medium, hands returning to rest, the same key light. A short pause
before the cut.
End state: the exact opening framing, hands at rest, no movement.

Same face, same hairstyle, same outfit for the entire video. Same wall, same two light sources.
No subtitles, no background music.
```

**Why it works:** the lines are short, one thought per breath. The last shot is the same frame as the
first, which holds the clip together without any editing graphics.

---

## 3. Reference mode, one character across all beats

**When:** an identity has to survive 30 seconds. The hardest case, and the main reason to want 2.5 at all.

**Mode name by surface:** `Omni Reference` on CapCut Desktop (requires version 840+), reference or
multimodal reference elsewhere. Confirm in `surface-profiles.md`.

**Reference binding:**

```
@Image1 defines the main character's identity: face, hair, grey wool coat. Do not take pose, background, or framing.
@Image2 defines the location and colour palette: wet cobblestone street at dusk. Do not take any person.
@Video1 defines camera rhythm only: the handheld drift and its pacing. Do not take appearance, wardrobe,
lighting, or location.
```

**Prompt:**

```
Constants: @Image1 is the only person in the clip and her appearance holds unchanged across every beat.
Location and palette follow @Image2 throughout. Camera rhythm follows @Video1. Dusk, wet ground, sodium
street lamps as the only warm source, cool ambient sky, no text.

00-06s: Wide shot of the empty street, lamps reflecting in the wet stone. She is not yet in frame.
End state: the street is still empty, the frame wide.

06-14s: She enters from the left in the grey wool coat, walking away from camera. Handheld follows at a
walking pace, holding her in the left third.
End state: she is mid-street, back to camera, held in the left third.

14-24s: She stops at a corner and turns back toward camera. The handheld settles. A car passes behind
her, its headlights crossing the wet stone.
End state: she faces camera at the corner, the car gone, the frame steady.

24-30s: Close-up of her face under the sodium lamp, then she looks off toward the empty street where the
clip opened. The handheld holds. Ambient street, no score.
End state: her face in close-up, eyeline off toward the opening street.

Same face, same hairstyle, same grey wool coat for the entire video. Same street, same lamps.
No subtitles. [SOUND] Strictly only naturally occurring sound and foley, no music allowed.
```

**Watch out:** if `@Video1` carried no appearance exclusion, the model would pull the donor's face and
clothing across and `@Image1` would lose. The exclusion is a functional part of the prompt, not a comment.

---

## 4. Before and after (image to video, start and end frame)

**When:** a renovation, an interior, a product, a makeover. If you have real photographs of both states,
use them as the actual first and last frame so the change lands on reality instead of a hallucination.
This template is for the case where you have the starting state and describe the goal in words.

```
Constants: the same room, the same camera position, the same window as the only light source, natural
grade, no people, no text.

00-06s: Static wide of the room in its current state, bare plaster, tools against the wall, dust in the
window light.
End state: the room is unchanged and the frame is wide.

06-14s: Slow push-in as the space begins to resolve: plaster giving way to finished wall, the light
unchanged.
End state: the walls are finished, the camera at a medium distance.

14-24s: Continue the push as flooring, then furniture, settle into place, one element at a time rather
than all at once. The window light holds its angle throughout.
End state: floor and furniture are in place, the room complete.

24-30s: Camera returns to the exact opening framing, now on the finished room. The same dust still
drifting in the same light.
End state: the exact opening framing, finished room, same dust in the same light.

Same room, same camera position, same window light angle for the entire video.
No people, no on-screen text, no hard cuts, nothing appears out of thin air.
```

**Callback:** identical composition at the start and the end is the entire point. The prompt has to say so
out loud, or the model wanders.

---

## What breaks repeatedly, and how to fix it

| Symptom | Cause | Fix |
|---|---|---|
| Clip falls apart into unrelated shots | four ideas instead of one arc | one subject, one intent, beats as phases |
| Character changes halfway through | constants unstated or only in beat 1 | a `Constants` block at the top, declared to hold for the whole clip |
| A donor reference pulled its look across | missing exclusion on `@Video` | "Do not take appearance, wardrobe, lighting, or location" |
| The ending just stops | no callback | beat four returns to a frame or object from beat one |
| Cut lands mid-movement | the beat ends inside the action | end the beat's sentence on the impact |
| Lines stumble or fall apart | longer lines because the clip is longer | back to one thought per breath |
| Motion looks weightless | a pose described instead of physics | the verb and its consequence, not an adjective |
| Stages blur into each other | missing `End state:` | add one to every beat |
| A beat feels rushed | the window is too narrow for what is in it | widen it or remove a change. Windows are budgets |
| Music appears despite "no music" | a weak negative | `[SOUND] Strictly only naturally occurring sound and foley, no music allowed.` |
| Face drifts toward the end | constants only at the top | `same face, same hairstyle, same outfit, same body type for the entire video` at the bottom |
| Crowd looks like clones | variety not requested | see the crowd line in `proven-fixes.md` |
| Part of the plot goes missing or the model improvises | **a gap in the timeline** (`0-3s… 5-6s…`) | windows must be contiguous `[official]` |
| Extra cuts inside one window | too much plot for the time | widen the window or remove a change |
| The model pads with invented business | too little plot for the time | say what happens in that window `[official]` |
| The same action repeats and reads cheap | every movement choreographed | describe actions generally, detail only a few memorable ones `[official]` |

Extension, editing finished footage, keyframes, storyboards, and 3D clay-model references are in
`modes-and-workflows.md`; the official contract is in `official-spec.md`. Repair lines are quoted
verbatim in `proven-fixes.md`.
