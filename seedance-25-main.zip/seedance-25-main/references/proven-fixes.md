# Proven repair lines, syntax, and reference limits

last_verified: 2026-08-09

Source for the repair lines and audio syntax: **PJ Ace, "One-Take Filmmaking with Seedance 2.5: Viral
Cheat Codes", 2026-08-04** `[community 2026-08-04]`. Practitioner-observed, not documented. It works,
but do not describe it as official.

**As of 2026-08-09, the "Reference sweet spots" and "What 2.5 fixed versus 2.0" sections are largely
`[official]`,** because BytePlus published documentation. Labels are on the individual items.

These are **verbatim lines you paste into a prompt.** Do not reword them into nicer English. They work
in exactly this form, and a reworded version is a different prompt.

---

## Kill switches

| Symptom | Line to paste |
|---|---|
| Music creeps in despite "no music" | `[SOUND] Strictly only naturally occurring sound and foley, no music allowed.` |
| Something appears or vanishes at a transition | `no hard cuts, nothing appears out of thin air` (at **every** transition point, and describe the transition explicitly) |
| Face drifts across a long clip | `same face, same hairstyle, same outfit, same body type for the entire video` |
| Crowd looks like clones | `background people differ in clothing color, hairstyle, and facial features; their dancing is not perfectly synchronized` |
| On-screen text comes out Chinese or garbled | `All on-screen text must be in English. No Chinese, other languages, or garbled characters.` (substitute your language) |

On the first row: a plain "no background music" in the negatives sometimes loses. A dedicated `[SOUND]`
directive wins. If a client needs a clean track to score later, use both.

---

## Emotion is shown, not named

Never `she is sad`. The model turns that into a sadness filter smeared over the whole face.

Write the visible signals: breathing, brow, gaze, a swallowed sob, a hand that stops halfway. **Pair
every emotion word with something a camera can actually see.** Same principle as anti-slop, applied to
performance.

---

## Audio tag syntax

`[community 2026-08-04]`, a convention shared across 2.5 surfaces:

| Notation | Meaning |
|---|---|
| `(music)` | round brackets: music |
| `<sound effect>` | angle brackets: SFX |
| `{dialogue}` | curly braces: a spoken line |
| `【subtitles】` | these brackets: subtitles |

For non-English dialogue, **name the language and accent before the line**, or the delivery drifts.

---

## Languages

You can write the prompt in your own language, but optimization is uneven:

- **Most heavily optimized:** Chinese, English, Spanish, Indonesian, Malay.
- **Fully supported:** Thai, Arabic, Portuguese, Vietnamese, Japanese, Korean.
- **Anything not on those lists** is unlisted, which is not the same as unsupported, but it does mean
  you are off the tested path.

**Practical rule: write the prompt in English** unless your language is on the first list. Dialogue and
on-screen text in an unlisted language can still be requested, but verify it on a short draft before
committing to a long generation, and always include the on-screen text directive above, or Chinese
characters tend to appear.

Localizing one ad across five markets is cheap this way: same prompt, different on-screen-text directive.

---

## Reference sweet spots

**Updated 2026-08-09: this table is now `[official]`.** The "ByteDance internal guidance" the second
source pointed at was published openly on 2026-08-07 as BytePlus documentation. **The numbers both
practitioners reported were correct.** The documentation adds a stretch band on top: values that will
go through, at the cost of stability and repeated attempts.

The model ceiling is 50: **30 images** (up to 4K each), **10 videos totalling ≤30s**, and **10 audio
clips totalling ≤30s**. Those combined-duration limits are easy to miss: ten five-second donors fit,
three fifteen-second donors do not.

| Type | Sweet spot | Stretch (works, but struggles) |
|---|---|---|
| Distinct subjects from images | **1-8** | 9-12 |
| Subjects from audio/video | **1-5** | 6-10 |
| Length of one audio/video reference | **5-10s** | longer |
| Source for editing | **≤20s** | longer |
| Reference images for an edit | **1-5** | 6-8 |
| Storyboard panels | **≤15** | more causes still frames and wrong ordering |

Three hard rules on top:

- **Multi-view inputs are allowed on 2.5** `[official]` and not on 2.0. Up to 5 subjects, multi-view
  is fine. Above 5, prefer one view per subject, and when you need several angles **split them into
  separate images**.
- **Several angles of one character inside a single image is wrong in every case.** The model reads it
  as one composition, not as three views. This still holds after multi-view was allowed, because
  multi-view means more files, not one file with more views in it.
- **Every reference must state what to take AND what to ignore.** "Do not use the background" is a
  functional part of the prompt. Without an exclusion the model takes everything. **Conversely, when a
  reference is accurate, do not describe the scene again** `[official]`: "Strictly refer to the actions
  and camera movements in Video 1" is enough, and spelling out its contents makes the result worse.

Role binding with named roles:

```
@Image1 defines <Bride>'s face, hairstyle, and dress. Do not use the background.
@Image2 defines <Groom>'s face and suit.
@Video1 defines only the slow-dance motion.
@Audio1 is the background music.
```

The angle brackets around a role (`<Bride>`) give the character a name you can refer back to in later
beats. With more than one character in a clip this saves repeating the description every time.

---

## What 2.5 fixed versus 2.0

**Documented differences** `[official 2026-08-07]`, safe to quote:

- **Timestamps.** 2.0 does not respond to them at all and understands only shot numbers. 2.5 supports
  **integer-second timestamps**. This is the cleanest functional split between the lines.
- **Multi-view references.** Not recommended on 2.0, supported on 2.5.
- **Aspect ratio.** 2.0 offers six fixed values, 2.5 handles **anything between 0.4 and 2.5**.
- **MOV output.** Holds colour, brightness, and audio-visual continuity better through editing and
  extension. 2.0 is mp4 only.
- **Duration and references.** 4-30s and 50 assets, against 4-15s and 12 assets.

**What 2.5 gives up for that:** resolution. **480p and 720p, no 1080p and no 4K.** 4K is on 2.0.

**Practitioner impressions with no published benchmark** `[community 2026-08-04]`, **do not repeat
these as fact in a client deck or a sponsored post without testing them yourself:**

- Multi-person casting: characters in the same frame no longer swap faces or merge into twins.
- Output looks less synthetic: skin texture, separated fur, natural speech, and complex motion
  (martial arts, dance, subtle facial acting) that used to fall apart.

**And one claim the documentation quietly undercuts:** "negatives finally obey". The official guide
says to write **positively**, and lists negatives as supported **only for subtitles and audio** (sound
effects, BGM, dialogue). A negative aimed at visuals is not a documented feature. So "no subtitles"
and "no BGM" are fine, but rewrite "no cars in the background" as a description of what should be
there instead.

---

## Pre-flight, the short version

Complements the full checklist in `SKILL.md`. Before you hit generate:

- [ ] Subject and main action stated plainly
- [ ] Every reference says what to use **and what to ignore**
- [ ] One primary change per stage, each with an `End state:`
- [ ] Character count, clothing, and prop ownership consistent across stages
- [ ] Forbidden list at the end (subtitles, background music, morphing, extra characters)
