# Surface profiles for Seedance 2.5

last_verified: 2026-08-09

Seedance 2.5 was announced **2026-07-31** and documented **2026-08-07**. Labels: `[official]`
BytePlus/Volcengine documentation or a ByteDance product page · `[press]` trade reporting ·
`[community]` a named, dated practitioner who actually shipped with it · `[verified-live]` checked
directly against a running surface on the date given · `[unverified]` waiting on a first real run.

`[community]` ranks above `[unverified]` and below `[press]`. Usable as working method, not usable as a
claim in client material or a sponsored post.

**How to use this:** pick the surface → read its profile → fill the settings block from it. Any value
without `[verified-live]` goes into the settings block with `(verify in UI)` beside it. Never carry a
number from one surface to another, not even between two ByteDance products.

> **The model ceiling no surface can exceed** `[official 2026-08-09]`: **480p and 720p, 4-30s,
> 24 fps.** Seedance 2.5 does not do 1080p and does not do 4K. When a profile below mentions "1080p
> coming soon", read it as surface marketing, not as the model's roadmap. 1080p and 4K exist only on
> Seedance 2.0, at 15 seconds. Until 2026-08-08 this file claimed you could get above 720p by going
> manual in CapCut. You cannot.

## Quick view

| Surface | 2.5 status | Practical note |
|---|---|---|
| Dreamina web | live `[press]` | the international copy-paste route, currently the most realistic path to 30s |
| CapCut Desktop | live `[official]`, UI described `[community 2026-08-04]` | Homepage > AI Video |
| Jimeng (CN) | live `[press]` | primary launch surface, features land here first |
| Doubao Pro | live `[press]` | rolling out |
| OpenArt | listed as a host `[press]` | third party, verify before relying on it |
| **BytePlus ModelArk / Volcengine Ark API** | **live and public** `[official 2026-08-09]` | `dreamina-seedance-2-5-260628`, individual tier exists, pricing published. Profile below |
| Runway | announced, not live `[press]` | do not count on it |
| **Magnific** | **2.5 live, 720p/480p only** `[verified-live 2026-08-07]` | `bytedance-seedance-pro-2.5`, 4-30s |
| **Higgsfield** | **2.5 live, 720p/480p only** `[verified-live 2026-08-07]` | `seedance_2_5`, 4-30s, four modes incl. video edit and extension |
| fal / Replicate / routers | not seen `[press]` | these carried 2.0, do not assume 2.5 |

---

## Dreamina web

`https://dreamina.capcut.com` · ByteDance's international surface · `[press]` live since launch

**Why here:** when you want 30 seconds now without installing a desktop app. Free daily credits have
been reported. The live duration selector is also the fastest ground truth on whether 2.5 is actually
available on a given account.

- **Model:** Seedance 2.5 is chosen in the model selector. Confirm you are not sitting on 2.0.
- **Duration:** 30s in one generation `[press]`.
- **Extension:** multi-turn extension beyond the base 30s is reported `[press]` without a visible spec.
  Do not promise it to a client before seeing it run.
- **References:** model ceiling of 50 (30 images / 10 videos / 10 audio) `[press]`. How many the Dreamina
  UI actually accepts is `[unverified]`.
- **Binding:** `@mention` convention, same as other ByteDance UIs `[unverified]` for Dreamina specifically.
- **Resolution and aspect:** which of 480p/720p Dreamina exposes is `[unverified]`. **4K is not on the
  table**, the model does not support it `[official 2026-08-09]`. Aspect can be anything between 0.4
  and 2.5 at model level; what the UI offers is `[unverified]`.

**Fill in after a first run:** the real reference ceiling, available resolutions, the aspect list,
whether duration is continuous or a fixed set, what the modes are called in the UI, whether Extension
exists and what it costs.

```
--- SETTINGS: DREAMINA ---
Mode: text to video / image to video / reference (verify names in UI)
Model: Seedance 2.5
Duration: 30s
Aspect: 16:9
Resolution: (verify in UI)
References: @Image1 = ..., @Video1 = ...
```

---

## CapCut Desktop

Homepage > AI Video · `[official]` from CapCut's own pages, 2026-08-01

**Evidence warning:** CapCut marketing pages are generated ahead of release, and one of them on the same
date listed 2.5 as "coming soon" while another described a finished workflow. Treat this profile as a
strong indication, not a spec. A first real run upgrades it to `[verified-live]`.

- **Path:** Homepage > AI Video.
- **Modes:** the picker has four entries `[community 2026-08-04]`: **Omni Reference** (default, text plus
  any mix of image/video/audio) · **Smart Edit** (upload a video, describe the change) · **Ultra-Long
  Video** (clock icon, 30-180s slider) · **First & Last Frame**. Earlier documentation listed only
  `Text to video` / `Image to video` / `Omni reference` (requires version 840+) `[official]`. Both can be
  true at once, the picker appears to have grown.
- **Model:** Seedance 2.5 is chosen in the model selector.
- **Duration:** up to **30s** in one generation `[official]`. **Extension** adds 4-30s per pass while
  the input stays ≤30s; the **60s ceiling** on the final cut is `[community 2026-08-04]` and the
  official documentation states no ceiling at all. **Ultra-Long at 30-180s** is also
  `[community 2026-08-04]` and **the official model card contradicts it** (documented duration is
  4-30s). Before offering it as a feature, have someone confirm the slider exists.
- **Resolution:** 480p and 720p. One CapCut page marked 1080p "coming soon", and **that cannot apply to
  2.5, which does not support 1080p** `[official 2026-08-09]`. Either it referred to the 2.0 line or
  it was marketing. Practical advice from users: **iterate at 480p**, upscale only the final.
  `[community 2026-08-04]`
- **Aspect:** Fit, Original, 9:16, 1:1, 3:4, 16:9, 4:3, 21:9. **Smart Edit cannot change the source
  aspect or duration.**
- **References:** imported with `+`. Video references are trimmed to **≤15s** (anything longer drops into
  a lightweight trimmer). The 50-input model ceiling has not been verified item by item here. The quality
  band sits well below the ceiling, see `proven-fixes.md`.
- **Binding:** `@mention`, in the form `@Image1`, `@Video1`, `@Audio1`.
- **Advanced Edit:** after uploading a local video, a toolbar appears with boxes, arrows, and markers you
  draw directly on a frame and then reference in the prompt ("inside the red box"). `[community 2026-08-04]`

**Fill in after a first run:** the real reference ceiling, whether 1080p is live, whether audio references
are available, exact `@` tag numbering, whether duration is continuous or fixed, and whether the picker
matches the community description from 2026-08-04.

```
--- SETTINGS: CAPCUT DESKTOP ---
Mode: Omni Reference / Smart Edit / Ultra-Long Video / First & Last Frame (verify in UI)
Model: Seedance 2.5
Duration: 30s
Aspect: 16:9
Resolution: 720p (iterate at 480p)
References: @Image1 = ..., @Video1 = ...
```

---

## Jimeng (CN) and Doubao Pro

`[press]` live. Jimeng is the primary launch surface, Doubao Pro is rolling out.

Features land here first and the UI is Chinese. If you hit a function the international surfaces do not
have, it probably came from here and **must not be carried into a prompt for Dreamina or CapCut**.

- Everything specific: `[unverified]`. Fill this in when someone on the team actually works there.
- Keep prompts in English. 2.5 is reportedly multilingual across 11 languages, but English is the tested
  path for the vocabulary this skill uses.

---

## BytePlus ModelArk / Volcengine Ark API

`[official 2026-08-09]` · **This profile reversed completely on 2026-08-09.** It previously said
"enterprise-only, no pricing, no model ID". All three were wrong.

- **Model ID:** `dreamina-seedance-2-5-260628`. For comparison, 2.0 is `dreamina-seedance-2-0-260128`.
  The prefix is `dreamina-`, not `doubao-`.
- **Resolution:** 480p, 720p. **No 1080p, no 4K.** 24 fps.
- **Duration:** 4-30s.
- **Formats:** `.mp4` and `.mov`. 2.0 does mp4 only. **mov** is recommended for editing and extension.
- **Region:** ap-southeast-1.
- **Limits:** individual 180 RPM / concurrency 3 · enterprise 600 RPM / concurrency 10.
  Offline (flex) inference is **not supported**.
- **Pricing** (USD per million tokens, online inference): input without video **10.70**, input with
  video **6.40**. For comparison, 2.0 at 480p/720p is 7.0 and 4.3; at 4K it is 4.0 and 2.4.
- **Tasks:** t2v, i2v first frame, i2v first+last, reference-to-video, multimodal reference-to-video,
  **video editing**, **video extension**.
- Seedance video generation is **always an async job** (submit → id → poll → URL), never a chat-shaped
  request.
- **References go in with a `content.role`**, not as `@mention` strings. Values: `first_frame`,
  `last_frame`, `reference_image`, `reference_video`, `reference_audio`. Roles and exclusions still
  belong **in the prompt too**, because that is where ownership is decided.
- **Locked tasks need `ratio = adaptive`**, and editing also needs `duration = -1`. See
  `official-spec.md` sections 1 to 3.

```
--- SETTINGS: MODELARK API ---
model: dreamina-seedance-2-5-260628
Duration: 30s        (editing: duration = -1)
Aspect: 16:9         (locked tasks: adaptive)
Resolution: 720p
output_format: mp4   (editing and extension: mov)
content.role: reference_image / reference_video / reference_audio / first_frame / last_frame
```

**Still to verify:** whether 2.5 is enabled on your account, and what one 30-second run actually costs
in tokens. Pricing is per million tokens, not per clip, so until one real generation completes, any
per-clip figure is an estimate.

---

## Agent surfaces (Magnific, Higgsfield)

`[verified-live 2026-08-07]`, read straight out of the model catalogs. **This changed under the skill's
feet in four days**, which is the whole argument for the evidence labels. On 2026-08-03 neither surface
carried 2.5. On 2026-08-07 both do.

**Magnific** (`video_models_list`):

- `bytedance-seedance-pro-2.5`, durations **4-30s**, resolutions **720p and 480p only**.
- References image×30 / video×10 / audio×10. Video references up to 30s and 200 MB each.
- Prompt ceiling 10 000 characters. Start and end keyframes supported, and **an end frame requires a
  start frame**.
- The 2.0 line is untouched: `bytedance-seedance-pro-2.0` at 4-15s, but with **4K and 1080p**.
- The catalog's own recommendation still ranks **2.0 as the top model**; 2.5 carries no recommendation
  tier at all. Read that as what it is: newer, longer, lower resolution.

**Higgsfield** (`models_explore`):

- `seedance_2_5`, duration **4-30s**, **480p / 720p**, `generate_audio` toggle.
- Four modes in one model: `t2v`, `omni_reference`, `video_edit`, `video_extension` (the last one takes
  `extension_mode: backward | forward`).
- Media roles are references only: `image_references`, `video_references`, `audio_references`. **No
  start or end frame role on 2.5**, unlike `seedance_2_0`, which still has both.

**The trade is resolution against length.** 2.5 buys 30 seconds, timestamps, and a much bigger
reference budget, and costs you everything above 720p. When the deliverable is a client master, 2.0 at
4K for 15 seconds is still the better tool. When the deliverable is length, coverage, or a look test,
take 2.5.

**This is not an agent-surface limitation.** `[official 2026-08-09]` 720p is the model's ceiling. The
earlier line here, that anything above 720p "remains a CapCut or Dreamina job", was wrong and is
withdrawn: going manual does not get you above 720p either, because there is nothing above it. The
only thing that stays manual is Ultra-Long, assuming it exists at all.

- fal, Replicate, OpenRouter and other routers: these carried 2.0, 2.5 was not visible on them `[press]`.

Re-check the catalogs before quoting this section. Four days was enough to invalidate it once already.

---

## Conservative profile (unknown surface)

When a surface is not in this file or nobody on the team has run it:

- Write the prompt for **one generation at a time**, without relying on extension.
- **State no number** the profile does not have: not duration, not resolution, not the reference ceiling.
- Preserve exactly the tags the user supplies. Do not renumber them.
- Prefer role-bound references over a claim about a feature.
- Write `(verify in UI)` next to everything unconfirmed, and **say out loud that the profile is
  conservative**.
- Ask for duration and aspect before generating. Never default them.

---

## Update protocol

When someone actually opens a surface and sees real numbers:

1. Rewrite the specific lines and mark them `[verified-live YYYY-MM-DD]`.
2. Bump `last_verified` at the top.
3. If the fact concerns the **model** rather than a UI, it belongs in `official-spec.md` and the model
   invariants in `SKILL.md`, not here. This file holds surfaces.
4. If a surface gains or loses 2.5, fix the quick view table as well.
